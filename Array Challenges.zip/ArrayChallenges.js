// Always Hungry
console.log("AlwaysHungry first run:");
AlwaysHungry([3.14,"food","pie",true,"food"]);
// this should console log "yummy, yummy"

console.log("AlwaysHungry second run:");
AlwaysHungry([4, 1, 5, 7, 2]);
// this should console log "I'm hungry"

function AlwaysHungry(arr) {
    var hungry = true;
    var yummy = "";
    for (var k = 0; k < arr.length; k++) {
        if (arr[k] == "food") {
            hungry = false;
            if (k < arr.length-1){
                yummy = yummy + "yummy, ";
            }
            else {
                yummy = yummy + "yummy";
            }
        }
    }
    if (hungry) {
        console.log("I'm Hungry.");
    }
    else {
        console.log(yummy);
    }
}

// High Pass Filter
console.log("highPass run:")
function highPass(arr, cutoff) {
    var filteredArr = [];
    // your code here
    for (var k = 0; k < arr.length; k++){
        if (arr[k] > cutoff) {
            filteredArr.push(arr[k]);
        }
    }
    return filteredArr;
}
var result = highPass([6, 8, 3, 10, -2, 5, 9], 5);
console.log(result); // we expect back [6, 8, 10, 9]

// Better Than Average
console.log("betterThanAverage run:");
function betterThanAverage(arr) {
    var sum = 0;
    // calculate the average
    for (var k = 0; k < arr.length; k++) {
        sum = sum + arr[k];
    }
    var avg = (sum / arr.length);

    var count = 0;
    // count how many values are greated than the average
    for (var j = 0; j < arr.length; j++) {
        if (arr[j] > avg) {
            count++;
        }
    }
    return count;
}
var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
console.log(result); // we expect back 4

// Array Reverse
console.log("reverse run:");
function reverse(arr) {
    // your code here
    var retArray = new Array();
    var index = 0;
    for (var k = (arr.length - 1); k >= 0; k--) {
        retArray[index] = arr[k];
        index++;
    }
    return retArray;
}

var result = reverse(["a", "b", "c", "d", "e"]);
console.log(result); // we expect back ["e", "d", "c", "b", "a"]

//Fibonnaci Array
console.log("fibonacciArray run:");
function fibonacciArray(n) {
    // the [0, 1] are the starting values of the array to calculate the rest from
    var fibArr = [0, 1];
    // your code here
    var sum = 0;
    let ptr = 0;
    while (fibArr.length < 10) {
        sum = fibArr[ptr] + fibArr[ptr+1];
        fibArr.push(sum);
        ptr++;
    }
    return fibArr;
}

var result = fibonacciArray(10);
console.log(result); // we expect back [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]